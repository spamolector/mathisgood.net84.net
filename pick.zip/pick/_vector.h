#include <windows.h>

/*
#define _0_malloc(n) HeapAlloc(GetProcessHeap(), 0, n)
#define _0_free(p) HeapFree(GetProcessHeap(), 0, p)
#define _0_realloc(p, n) HeapReAlloc(GetProcessHeap(), 0, p, n)
#define _0_memcpy(p2, p1, s) memcpy(p2, p1, s)
*/

#define _0_malloc(n) t32_malloc(n)
#define _0_free(p) t32_free(p)
#define _0_realloc(p, n) t32_realloc(p, n)
#define _0_memcpy(p1, p2, s) t32_memcpy(p1, p2, s)

template<class T> struct _vector {
	static const u_long defInitialAllocation = 8;
	T *memory;
	UINT elementsAllocated, elementsUsed;
	BOOL init (UINT initialAllocation) {
		if(initialAllocation == 0) {
			return init();
		} else {
			elementsUsed = 0;
			elementsAllocated = initialAllocation;
			memory = (T*)_0_malloc(sizeof(T)*elementsAllocated);
			return (memory != 0);
		}
	}
	BOOL init () {
		return init(defInitialAllocation);
	}
	BOOL uninit () {
		if(memory) {
			_0_free(memory);
		}
		return TRUE;
	}
	BOOL cat (T *elements, UINT count) {
		BOOL bRet;
		T *t;
		bRet = TRUE;
		while(elementsAllocated < elementsUsed + count) {
			t = (T*)_0_realloc(memory, sizeof(T)*elementsAllocated*2);
			if(t != 0) {
				elementsAllocated *= 2;
				memory = t;
			} else {
				bRet = FALSE;
				break;
			}
		}
		if(bRet) {
			_0_memcpy(&memory[elementsUsed], elements, sizeof(T)*count);
			elementsUsed += count;
		}
		return bRet;
	}
	BOOL push (T value) {
		cat(&value, 1);
		return TRUE;
	}
	T& operator[] (UINT position) {
		T *t;
		t = 0;
		if(position < elementsAllocated) {
			return memory[position];
		}
		return *t;
	};
    const T& operator[] (UINT position) const {
		return this[position];
	};
};