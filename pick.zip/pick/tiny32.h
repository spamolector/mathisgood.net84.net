#pragma once
#include <windows.h>

int t32_main (int, LPWSTR*);
int WINAPI t32_WinMain (HINSTANCE, HINSTANCE, LPSTR, int);
void __WTF (LPWSTR);

#define MAX_PATH_W 32767

bool operator== (const LARGE_INTEGER& left, const LARGE_INTEGER& right) {
	return left.HighPart == right.HighPart && left.LowPart == right.LowPart;
}

void t32_free (LPVOID lpMem) {
	HeapFree(GetProcessHeap(), 0, lpMem);
}
LPVOID t32_malloc (SIZE_T dwBytes) {
	return HeapAlloc(GetProcessHeap(), 0, dwBytes);
}
LPVOID t32_realloc (LPVOID lpMem, SIZE_T dwBytes) {
	return HeapReAlloc(GetProcessHeap(), 0, lpMem, dwBytes);
}
void t32_memcpy (LPVOID dst, LPVOID src, SIZE_T size) {
	while (size --) {
		*(char *)dst = *(char *)src;
		dst = (char *)dst + 1;
		src = (char *)src + 1;
    }
}
void t32_zero (LPVOID dst, SIZE_T size) {
	while (size --) {
		*(char *)dst = (char)0;
		dst = (char *)dst + 1;
    }
}

struct t32file_ {
	HANDLE hFile;
	union {
	LPVOID szName;
	LPSTR szNameA;
	LPWSTR szNameW;
	};
	BOOL close () {
		t32_free(szName);
		CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
		return TRUE;
	}
	DWORD write (LPVOID lpData, DWORD dwSize) {
		DWORD w = 0;
		WriteFile(hFile, lpData, dwSize, &w, 0);
		return w;
	}
	DWORD read (LPVOID lpData, DWORD dwSize) {
		DWORD r = 0;
		ReadFile(hFile, lpData, dwSize, &r, 0);
		return r;
	}
	BOOL getSize (PLARGE_INTEGER lpSize) {
		return GetFileSizeEx(hFile, lpSize);
	}
	BOOL getPos (PLARGE_INTEGER lpPos) {
		LARGE_INTEGER pos0 = {0};
		return SetFilePointerEx(hFile, pos0, lpPos, FILE_CURRENT);
	}
	BOOL setPos (PLARGE_INTEGER lpPos) {
		return SetFilePointerEx(hFile, *lpPos, 0, FILE_BEGIN);
	}
	BOOL relPos (PLARGE_INTEGER lpPos) {
		return SetFilePointerEx(hFile, *lpPos, 0, FILE_CURRENT);
	}
	BOOL endPos () {
		LARGE_INTEGER pos0 = {0};
		return SetFilePointerEx(hFile, pos0, 0, FILE_END);
	}
	BOOL eof () {
		LARGE_INTEGER uSize = {0}, uPos = {0};
		return getPos(&uPos) && getSize(&uSize) && 
			uPos == uSize;
	}
	BOOL putsA (LPSTR lpStr) {
		return write(lpStr, lstrlenA(lpStr)) > 0;
	}
	BOOL putsW (LPWSTR lpStr) {
		return write(lpStr, lstrlenW(lpStr)*2) > 0;
	}
	BOOL setAttributes (DWORD dwAttributes) {
		FILE_ATTRIBUTE_TAG_INFO fati;
		fati.FileAttributes = dwAttributes;
		fati.ReparseTag = 0;
		return SetFileInformationByHandle(hFile, FileAttributeTagInfo, &fati, sizeof(FILE_ATTRIBUTE_TAG_INFO));
	}
	BOOL getAttributes (LPDWORD lpdwAttributes) {
		BY_HANDLE_FILE_INFORMATION bhfi;
		BOOL bRet;
		if(bRet = GetFileInformationByHandle(hFile, &bhfi)) {
			*lpdwAttributes = bhfi.dwFileAttributes;
		}
		return bRet;
	}
};
struct t32fileA : t32file_ {
	//LPSTR szName;
	BOOL assign (LPSTR fname) {
		if(!(szNameA = (LPSTR)t32_malloc((lstrlenA(fname)+1)))) {
			return FALSE;
		}
		lstrcpyA(szNameA, fname);
		return TRUE;
	}
	BOOL reset () {
		BOOL bRet;
		bRet = (hFile = CreateFileA(szNameA, GENERIC_READ, 
			FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, 
			0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0)) != INVALID_HANDLE_VALUE;
		return bRet;
	}
	BOOL rewrite () {
		BOOL bRet;
		bRet = (hFile = CreateFileA(szNameA, GENERIC_WRITE, 
			FILE_SHARE_READ, 
			0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0)) != INVALID_HANDLE_VALUE;
		return bRet;
	}
	BOOL append () {
		BOOL bRet;
		if(bRet = (hFile = CreateFileA(szNameA, GENERIC_WRITE, 
			FILE_SHARE_READ, 
			0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0)) != INVALID_HANDLE_VALUE) {
			endPos();
		}
		return bRet;
	}
};
struct t32fileW : t32file_ {
	//LPWSTR szName;
	BOOL assign (LPWSTR fname) {
		if(!(szNameW = (LPWSTR)t32_malloc((lstrlenW(fname)+1)*2))) {
			return FALSE;
		}
		lstrcpyW(szNameW, fname);
		return TRUE;
	}
	BOOL reset () {
		BOOL bRet;
		bRet = (hFile = CreateFileW(szNameW, GENERIC_READ, 
			FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, 
			0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0)) != INVALID_HANDLE_VALUE;
		return bRet;
	}
	BOOL rewrite () {
		BOOL bRet;
		bRet = (hFile = CreateFileW(szNameW, GENERIC_WRITE, 
			FILE_SHARE_READ, 
			0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0)) != INVALID_HANDLE_VALUE;
		return bRet;
	}
	BOOL append () {
		BOOL bRet;
		if(bRet = (hFile = CreateFileW(szNameW, GENERIC_WRITE, 
			FILE_SHARE_READ, 
			0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0)) != INVALID_HANDLE_VALUE) {
			endPos();
		}
		return bRet;
	}
};
struct t32console {
	HANDLE stdin, stdout, stderr;
	BOOL attach (DWORD dwPid) {
		BOOL bRet;
		if(bRet = AttachConsole(dwPid)) {
			bRet = bRet && init();
		}
		return bRet;
	}
	BOOL parent () {
		return attach(ATTACH_PARENT_PROCESS);
	}
	BOOL create () {
		BOOL bRet;
		if(bRet = AllocConsole()) {
			bRet = bRet && init();
		}
		return bRet;
	}
	BOOL close () {
		return FreeConsole();
	}
	BOOL init () {
		stdin = GetStdHandle(STD_INPUT_HANDLE);
		stdout = GetStdHandle(STD_OUTPUT_HANDLE);
		stderr = GetStdHandle(STD_ERROR_HANDLE);
		return SetConsoleMode(stdout, ENABLE_LINE_INPUT | ENABLE_ECHO_INPUT | ENABLE_PROCESSED_INPUT);
	}
	DWORD writeA (LPSTR lpStr, DWORD dwSize) {
		DWORD w = 0;
		WriteConsoleA(stdout, lpStr, dwSize, &w, 0);
		return w;
	}
	DWORD readA (LPSTR lpStr, DWORD dwSize) {
		DWORD r = 0;
		ReadConsoleA(stdin, lpStr, dwSize, &r, 0);
		return r;
	}
	DWORD writeW (LPWSTR lpStr, DWORD dwSize) {
		DWORD w = 0;
		WriteConsoleW(stdout, lpStr, dwSize, &w, 0);
		return w;
	}
	DWORD readW (LPWSTR lpStr, DWORD dwSize) {
		DWORD r = 0;
		ReadConsoleW(stdin, lpStr, dwSize, &r, 0);
		return r;
	}
	BOOL gotoxy (SHORT x, SHORT y) {
		COORD p;
		p.X = x;
		p.Y = y;
		return SetConsoleCursorPosition(stdout, p);
	}
	BOOL getWindowSize (COORD *uSize) {
		_CONSOLE_SCREEN_BUFFER_INFO csbi;
		BOOL bRet;
		if(bRet = GetConsoleScreenBufferInfo(stdout, &csbi)) {
			uSize->X = csbi.srWindow.Right - csbi.srWindow.Left+1;
			uSize->Y = csbi.srWindow.Bottom - csbi.srWindow.Top+1;
		}
		return bRet;
	}
	BOOL getBufferSize (COORD *uSize) {
		_CONSOLE_SCREEN_BUFFER_INFO csbi;
		BOOL bRet;
		if(bRet = GetConsoleScreenBufferInfo(stdout, &csbi)) {
			*uSize = csbi.dwSize;
		}
		return bRet;
	}
	BOOL fitWindow () {
		COORD uSize;
		BOOL bRet;
		if(bRet = getWindowSize(&uSize)) {
			bRet = bRet && SetConsoleScreenBufferSize(stdout, uSize);
			__WTF(L"SetConsoleScreenBufferSize");
		}
		return bRet;
	}
	BOOL putsA (LPSTR lpStr) {
		return writeA(lpStr, lstrlenA(lpStr)) > 0;
	}
	BOOL putsW (LPWSTR lpStr) {
		return writeW(lpStr, lstrlenW(lpStr)) > 0;
	}
	BOOL getsA (LPSTR lpStr, int iSize) {
		LPSTR lpBuf;
		BOOL bRet = FALSE;
		DWORD r;
		if(lpBuf = (LPSTR)t32_malloc(iSize+2)) {
			if((r = readA(lpBuf, iSize+2)) >= 2) {
				bRet = TRUE;
				lstrcpynA(lpStr, lpBuf, r-1);
			}
			t32_free(lpBuf);
		}
		return bRet;
	}
	BOOL getsW (LPWSTR lpStr, int iSize) {
		LPWSTR lpBuf;
		BOOL bRet = FALSE;
		DWORD r;
		if(lpBuf = (LPWSTR)t32_malloc((iSize+2)*sizeof(WCHAR))) {
			if((r = readW(lpBuf, iSize+2)) >= 2) {
				bRet = TRUE;
				lstrcpynW(lpStr, lpBuf, r-1);
			}
			t32_free(lpBuf);
		}
		return bRet;
	}
	BOOL pause () {
		char c[2];
		return readA(c, 2) > 0;
	}
};
struct t32filesA {
	static BOOL fileExists (LPSTR lpFileName) {
		DWORD dwAttrib = GetFileAttributesA(lpFileName);
		return (dwAttrib != INVALID_FILE_ATTRIBUTES && 
			!(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
	}
	static BOOL directoryExists (LPSTR lpDirName) {
		DWORD dwAttrib = GetFileAttributesA(lpDirName);
		return (dwAttrib != INVALID_FILE_ATTRIBUTES && 
			(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
	}
	static BOOL createDirectory (LPSTR lpDirName) {
		return CreateDirectoryA(lpDirName, 0);
	}
	static BOOL deleteDirectory (LPSTR lpDirName) {
		return RemoveDirectoryA(lpDirName);
	}
	static BOOL deleteFile (LPSTR lpFileName) {
		return DeleteFileA(lpFileName);
	}
	static BOOL setAttributes (LPSTR lpFileName, DWORD dwAttributes) {
		return SetFileAttributesA(lpFileName, dwAttributes);
	}
	static BOOL getAttributes (LPSTR lpFileName, LPDWORD lpdwAttributes) {
		BOOL bRet = FALSE;
		DWORD dwAttrib = GetFileAttributesA(lpFileName);
		if(dwAttrib != INVALID_FILE_ATTRIBUTES) {
			*lpdwAttributes = dwAttrib;
			bRet = TRUE;
		}
		return bRet;
	}
	typedef BOOL (CALLBACK *FILEENUMPROCA)(WIN32_FIND_DATAA, LPARAM);
	static BOOL WINAPI EnumFiles (LPSTR lpSearchMask, FILEENUMPROCA lpEnumFunc, LPARAM lParam) {
		WIN32_FIND_DATAA fd;
		BOOL bRet = FALSE;
		HANDLE hEnum = FindFirstFileA(lpSearchMask, &fd);
		if(hEnum != INVALID_HANDLE_VALUE) {
			bRet = TRUE;
			do {
				if(lstrcmpA(fd.cFileName, "..") == 0 || lstrcmpA(fd.cFileName, ".") == 0) {
					continue;
				}
				bRet = lpEnumFunc(fd, lParam);
			} while(bRet && FindNextFileA(hEnum, &fd));
			if(GetLastError() != ERROR_NO_MORE_FILES) {
				bRet = FALSE;
			}
			FindClose(hEnum);
		}
		return bRet;
	}
};
struct t32filesW {
	static BOOL fileExists (LPWSTR lpFileName) {
		DWORD dwAttrib = GetFileAttributesW(lpFileName);
		return (dwAttrib != INVALID_FILE_ATTRIBUTES && 
			!(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
	}
	static BOOL directoryExists (LPWSTR lpDirName) {
		DWORD dwAttrib = GetFileAttributesW(lpDirName);
		return (dwAttrib != INVALID_FILE_ATTRIBUTES && 
			(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
	}
	static BOOL createDirectory (LPWSTR lpDirName) {
		return CreateDirectoryW(lpDirName, 0);
	}
	static BOOL deleteDirectory (LPWSTR lpDirName) {
		return RemoveDirectoryW(lpDirName);
	}
	static BOOL deleteFile (LPWSTR lpFileName) {
		return DeleteFileW(lpFileName);
	}
	static BOOL setAttributes (LPWSTR lpFileName, DWORD dwAttributes) {
		return SetFileAttributesW(lpFileName, dwAttributes);
	}
	static BOOL getAttributes (LPWSTR lpFileName, LPDWORD lpdwAttributes) {
		BOOL bRet = FALSE;
		DWORD dwAttrib = GetFileAttributesW(lpFileName);
		if(dwAttrib != INVALID_FILE_ATTRIBUTES) {
			*lpdwAttributes = dwAttrib;
			bRet = TRUE;
		}
		return bRet;
	}
	typedef BOOL (CALLBACK *FILEENUMPROCW)(WIN32_FIND_DATAW, LPARAM);
	static BOOL WINAPI EnumFiles (LPWSTR lpSearchMask, FILEENUMPROCW lpEnumFunc, LPARAM lParam) {
		WIN32_FIND_DATAW fd;
		BOOL bRet = FALSE;
		HANDLE hEnum = FindFirstFileW(lpSearchMask, &fd);
		if(hEnum != INVALID_HANDLE_VALUE) {
			bRet = TRUE;
			do {
				if(lstrcmpW(fd.cFileName, L"..") == 0 || lstrcmpW(fd.cFileName, L".") == 0) {
					continue;
				}
				bRet = lpEnumFunc(fd, lParam);
			} while(bRet && FindNextFileW(hEnum, &fd));
			if(GetLastError() != ERROR_NO_MORE_FILES) {
				bRet = FALSE;
			}
			FindClose(hEnum);
		}
		return bRet;
	}
};

struct debug {
	static void __WTF (LPWSTR s) {
		LPWSTR lpszError, lpszMsg;
		DWORD ec = GetLastError();
		FormatMessageW(
			FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			ec,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPWSTR) &lpszError,
			0, NULL);
		lpszMsg = (LPWSTR)t32_malloc((lstrlenW(lpszError) + lstrlenW(s) + 1 + 12)*sizeof(WCHAR));
		wsprintfW(lpszMsg, L"%s %08x %s", s, ec, lpszError);
		MessageBoxW(0, lpszMsg, L"", 0);
		t32_free(lpszMsg);
		LocalFree(lpszError);
	}
};

void __stdcall tiny32_exe_entry () {
	int iRet = 0;
	HMODULE hInst = GetModuleHandleW(0);
	STARTUPINFOA si;
	LPWSTR lpCmd, *lpArgv;
	int iArgc;

	GetStartupInfoA(&si);
	lpCmd = GetCommandLineW(); 
	lpArgv = CommandLineToArgvW(lpCmd, &iArgc);
	//iRet = t32_WinMain(hInst, 0, lpCmd, si.wShowWindow);
	iRet = t32_main(iArgc, lpArgv);
	ExitProcess(iRet);
}