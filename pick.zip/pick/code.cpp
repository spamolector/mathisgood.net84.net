#include <windows.h>
#include "tiny32.h"
#include "_vector.h"

BOOL enableConsole, showFullTime, enableWOW64FSRdisable;

struct DTP;
struct PARA {
	LPWSTR root;
	t32console *console;
	t32fileW *file;
	_vector<DTP> *dtpv;
	_vector<DWORD> *pbv;
	DWORD dtpi;
	t32fileW *dump;
};
typedef PARA *LPPARA;

void dual (LPWSTR lpStr, LPPARA para) {
	para->console->putsW(lpStr);
	para->file->putsW(lpStr);
}

// <time>
LPWSTR time0_ () {
	SYSTEMTIME st;
	static WCHAR buf[64], buf2[32];
	lstrcpyW(buf, L"");
	if(GetDateFormatW(LOCALE_SYSTEM_DEFAULT, 0, 
		&st, 0, buf2, sizeof(buf)) != 0) {
		lstrcatW(buf, buf2);
	}
	lstrcatW(buf, L" ");
	if(GetTimeFormatW(LOCALE_SYSTEM_DEFAULT, 0, 
		&st, 0, buf2, sizeof(buf)) != 0) {
		lstrcatW(buf, buf2);
	}
	return buf;
}
void time0 (LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	dual(time0_(), (LPPARA)lParam);
	dual(L"\r\n", (LPPARA)lParam);
}
void time1_ (FILETIME *tm) {
	GetSystemTimeAsFileTime(tm);
}
LPWSTR time2_ (FILETIME *tm, FILETIME *tm2) {
	static WCHAR snum[64];
	tm2->dwHighDateTime -= tm->dwHighDateTime;
	tm2->dwLowDateTime -= tm->dwLowDateTime;
	wsprintfW(snum, L"%u m %u s %u ms\r\n", 
		tm2->dwLowDateTime/600000000, 
		(tm2->dwLowDateTime/10000000)%60, 
		(tm2->dwLowDateTime/10000)%1000);
	return snum;
}
void time2 (FILETIME *tm, FILETIME *tm2, LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	dual(time2_(tm, tm2), (LPPARA)lParam);
	dual(L"\r\n", (LPPARA)lParam);
}
// </time>

// <dump>
struct FDR {
	DWORD prev;
	WIN32_FIND_DATAW fd;
};
void addFDR (WIN32_FIND_DATAW *fd, DWORD dtpi, LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	para->dump->write(&dtpi, sizeof(DWORD));
	para->dump->write(fd, sizeof(WIN32_FIND_DATAW));
}
// </dump>

// <ref>
struct DTP {
	WCHAR name[MAX_PATH];
	DWORD prev;
};

void buildPath (LPWSTR lpszPath, DWORD dtpi, LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	DWORD i = dtpi;
	para->pbv->elementsUsed = 0;
	do {
		para->pbv->push(i);
		i = para->dtpv->operator[](i).prev;
	} while (i != 0);
	lstrcpyW(lpszPath, L"");
	for(i = 0; i < para->pbv->elementsUsed; i ++) {
		lstrcatW(lpszPath, para->dtpv->operator[](para->pbv->operator[](para->pbv->elementsUsed-1-i)).name);
		lstrcatW(lpszPath, L"\\");
	}
	lstrcatW(lpszPath, L"*");
}

BOOL CALLBACK refc (WIN32_FIND_DATAW fd, LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	static WCHAR path[MAX_PATH_W];
	DTP find;
	addFDR(&fd, para->dtpi, lParam);
	dual(L"  > ", (LPPARA)lParam);
	buildPath(path, para->dtpi, lParam);
	path[lstrlenW(path)-1] = L'\0';
	dual(path, (LPPARA)lParam);
	dual(fd.cFileName, (LPPARA)lParam);
	if(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
		dual(L"\\", (LPPARA)lParam);
		lstrcpyW(find.name, fd.cFileName);
		find.prev = para->dtpi;
		para->dtpv->push(find);
	}
	dual(L"\r\n", (LPPARA)lParam);
	return TRUE;
}

void initDT (LPWSTR lpszBasePath, LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	DTP base;
	DWORD p, m, s;
	WIN32_FIND_DATAW fd;
	LPWSTR pre[]={L"\\\\?\\", L"\\", L"\\\\?\\UNC\\"};
	WCHAR buf[10];

	lstrcpyW(base.name, L"*?ROOT?ROOT?ROOT?ROOT?ROOT?*");
	base.prev = 0xFFFFFFFF;
	para->dtpv->push(base);
	para->dtpi = 0;
	s = lstrlenW(lpszBasePath);
	p = 0; m = 0;
	for(int i = 0; i < sizeof(pre)/sizeof(LPWSTR); i ++) {
		lstrcpynW(buf, lpszBasePath, m = lstrlenW(pre[i])+1);
		if(lstrcmpiW(buf, pre[i]) == 0) {
			p += m;
			break;
		}
	}
	if(p == 0) {
		m = 0;
	}
	while(p < s) {
		while(lpszBasePath[p] != L'\\' && p < s) {
			p ++;
			m ++;
		}
		if(m > 0) {
			lstrcpynW(base.name, &lpszBasePath[p-m], m+1);
			base.prev = para->dtpi;
			para->dtpv->push(base);
			para->dtpi ++; 
			p ++;
			m = 0;
		}
	}
	t32_zero(&fd, sizeof(WIN32_FIND_DATAW));
	for(DWORD i = 0; i < para->dtpv->elementsUsed; i ++) {
		lstrcpyW(fd.cFileName, para->dtpv->operator[](i).name);
		addFDR(&fd, para->dtpv->operator[](i).prev, lParam);
	}
}

void ref (LPWSTR lpszBase, LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	_vector<DTP> dtpv;
	_vector<DWORD> pbv;
	static WCHAR path[MAX_PATH_W];
	dtpv.init();
	para->dtpv = &dtpv;
	pbv.init();
	para->pbv = &pbv;
	initDT(lpszBase, lParam);
	while(para->dtpi < para->dtpv->elementsUsed) {
		buildPath(path, para->dtpi, lParam);
		t32filesW::EnumFiles(path, refc, lParam);
		para->dtpi ++;
	}
	dtpv.uninit();
	pbv.uninit();
}
// </ref>

// <volume>
typedef NAMEENUMPROCW VOLUMEENUMPROCW;

BOOL WINAPI EnumVolumesW (VOLUMEENUMPROCW lpEnumFunc, LPARAM lParam) {
	WCHAR szBuf[MAX_PATH];
	BOOL bRet = FALSE;
	HANDLE hEnum = FindFirstVolumeW(szBuf, sizeof(szBuf));
	if(hEnum != INVALID_HANDLE_VALUE) {
		bRet = TRUE;
		do {
			bRet = lpEnumFunc(szBuf, lParam);
		} while(bRet && FindNextVolumeW(hEnum, szBuf, sizeof(szBuf)));
		if(GetLastError() != ERROR_NO_MORE_FILES) {
			bRet = FALSE;
		}
		FindVolumeClose(hEnum);
	}
	return bRet;
}

LPWSTR driveType (LPWSTR lpszVolume) {
	UINT u = GetDriveTypeW(lpszVolume);
	LPWSTR c;
	switch(u) {
	case DRIVE_UNKNOWN:
		c = L"UNKNOWN";
		break;
	case DRIVE_NO_ROOT_DIR:
		c = L"invalid_path";
		break;
	case DRIVE_REMOVABLE:
		c = L"REMOVEABLE";
		break;
	case DRIVE_FIXED:
		c = L"FIXED";
		break;
	case DRIVE_REMOTE:
		c = L"REMOTE";
		break;
	case DRIVE_CDROM:
		c = L"CDROM";
		break;
	case DRIVE_RAMDISK:
		c = L"RAM";
		break;
	default:
		c = L"n/a";
	}
	return c;
}

BOOL getVolumeMaxNameLength (LPWSTR lpszVolume, LPDWORD dwLength) {
	return GetVolumeInformationW(lpszVolume, 0, 0, 0,
		dwLength, 0, 0, 0);
}

BOOL CALLBACK evc (LPWSTR lpszVolume, LPARAM lParam) {
	LPPARA para = (LPPARA)lParam;
	FILETIME ot, ot2;
	dual(L"@ ", (LPPARA)lParam);
	dual(lpszVolume, (LPPARA)lParam);
	dual(L"\r\n", (LPPARA)lParam);
	dual(L" Type:", (LPPARA)lParam);
	dual(driveType(lpszVolume), (LPPARA)lParam);
	dual(L"\r\n", (LPPARA)lParam);
	
	time1_(&ot);
	ref(lpszVolume, lParam);
	time1_(&ot2);
	time2(&ot, &ot2, lParam);
	dual(L"\r\n", (LPPARA)lParam);

	return TRUE;
}

void ev (LPARAM lParam) {
	EnumVolumesW(evc, lParam);
}
// </volume>

// <wow64redirection>
struct {
	PVOID wow64fsrov;
	typedef BOOL (__stdcall *pfrev)(PVOID);
	typedef BOOL (__stdcall *pfdis)(PVOID*);
	pfrev frev;
	pfdis fdis;
	void load () {
		wow64fsrov = NULL;
		HMODULE hLib = GetModuleHandleW(L"kernel32.dll");
		if(hLib) {
			fdis = (pfdis)GetProcAddress(hLib, "Wow64DisableWow64FsRedirection");
			frev = (pfrev)GetProcAddress(hLib, "Wow64RevertWow64FsRedirection");
		}
	}
	void disableWOW64FS () {
		if(fdis) {
			fdis(&wow64fsrov);
		}
	}
	void enableWOW64FS () {
		if(frev) {
			frev(wow64fsrov);
		}
	}
} wow64fsr;
// </wow64redirection>

void app () {
	FILETIME ot, ot2;
	PARA p;
	t32console c;
	t32fileW f;
	t32fileW d;
	f.assign(L"console.log");
	f.rewrite();
	d.assign(L"dump.fdr");
	d.rewrite();
	if(enableConsole) {
		c.create();
	}
	p.console = &c;
	p.file = &f;
	p.dump = &d;

	time0((LPARAM)&p);
	time1_(&ot);
	dual(L"Volumes:\r\n", &p);
	ev((LPARAM)&p);
	time1_(&ot2);
	time2(&ot, &ot2, (LPARAM)&p);

	dual(L"HALT", &p);
	if(enableConsole) {
		c.pause();
	}

	f.close();
	d.close();
	if(enableConsole) {
		c.close();
	}
}

//###################################################

int t32_main (int argc, LPWSTR *argv) {
	FILETIME ot, ot2;
	enableConsole = FALSE;
	showFullTime = FALSE;
	enableWOW64FSRdisable = TRUE;
	for(int i = 1; i < argc; i ++) {
		enableConsole |= lstrcmpiW(argv[i], L"/console") == 0;
		enableWOW64FSRdisable &= lstrcmpiW(argv[i], L"/wow64fsr") == 0;
		showFullTime |= lstrcmpiW(argv[i], L"/fulltime") == 0;
	}
	if(enableWOW64FSRdisable) {
		wow64fsr.load();
		wow64fsr.disableWOW64FS();
	}
	if(showFullTime) {
		time1_(&ot);
	}
	app();
	if(showFullTime) {
		time1_(&ot2);
		MessageBoxW(0, time2_(&ot, &ot2), L"Operation time", 0);
	}
	if(enableWOW64FSRdisable) {
		wow64fsr.enableWOW64FS();
	}
	return 0;
}

int WINAPI WinMain (HINSTANCE _aau, HINSTANCE _aba, LPSTR _aab, int _aaa) {
	int iRet = 0;
	HMODULE hInst = GetModuleHandleW(0);
	STARTUPINFOA si;
	LPWSTR lpCmd, *lpArgv;
	int iArgc;
	GetStartupInfoA(&si);
	lpCmd = GetCommandLineW(); 
	lpArgv = CommandLineToArgvW(lpCmd, &iArgc);
	iRet = t32_main(iArgc, lpArgv);
	return iRet;
}