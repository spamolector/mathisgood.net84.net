#pragma comment(linker, "/ENTRY:win32tiny_entry")

#include <windows.h>
#include <Shlobj.h>
#include "res.h"

void * __cdecl tiny_mem_set(void *pTarget, char value, size_t cbTarget) {
	_asm {
		push ecx
			push edi

			mov al, value
			mov ecx, cbTarget
			mov edi, pTarget
			rep stosb

			pop edi
			pop ecx
	}
	return pTarget;
}

#define MAX_PATH_W 32767

// global variables
HWND g_hMain;
HINSTANCE g_hInstance;
LPWSTR g_szDumpTo, g_szDumpFrom;
HANDLE g_hThr;
DWORD g_dwTid;
BOOL g_stop;
HANDLE g_dumpFileName, g_dumpFileInfo, g_dumpFile;

// function prototypes
static BOOL CALLBACK DialogFunc (HWND, UINT, WPARAM, LPARAM);
void NotImplemented ();
LPWSTR GetDumpSaveFileName ();
LPWSTR GetTargetPathDirectory ();
LPWSTR MakeFileNameBufferW ();
LPVOID halloc (size_t);
void hfree (LPVOID);
void SetEditText (LPWSTR, int);
void StartDumpFiles ();
void StopDumpFiles ();
void StartDumpFiles__ ();
void StopDumpFiles__ ();
void DumpFiles (LPVOID);
void RecursiveSearchFiles (LPWSTR);
LONG WINAPI seh (struct _EXCEPTION_POINTERS *);
void __WTF(LPWSTR);

void __stdcall win32tiny_entry () {
	UINT uRet;

	SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)seh);
	uRet =  DialogBoxW(GetModuleHandleW(0), MAKEINTRESOURCEW(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);

	ExitProcess(uRet);
}

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam) {
	LPWSTR ts;
	switch (msg) {
	case WM_INITDIALOG:
		g_hMain = hwndDlg;
		g_szDumpTo = MakeFileNameBufferW();
		g_szDumpFrom = MakeFileNameBufferW();
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDB_DUMP:
			SetEditText(L"in progress", IDS_DUMP_STATUS);
			GetWindowTextW(GetDlgItem(g_hMain, IDE_DUMP_FROM), g_szDumpFrom, MAX_PATH_W);
			GetWindowTextW(GetDlgItem(g_hMain, IDE_DUMP_TO), g_szDumpTo, MAX_PATH_W);
			StartDumpFiles();
			return TRUE;
		case IDB_DUMP_STOP:
			SetEditText(L"stopped", IDS_DUMP_STATUS);
			StopDumpFiles();
			return TRUE;
		case IDB_DUMP_FROM_BROWSE:
			ts = GetTargetPathDirectory();
			if(ts) {
				SetEditText(ts, IDE_DUMP_FROM);
				hfree(ts);
			}
			return TRUE;
		case IDB_DUMP_TO_BROWSE:
			ts = GetDumpSaveFileName();
			if(ts) {
				SetEditText(ts, IDE_DUMP_TO);
				hfree(ts);
			}
			return TRUE;
		}
		return FALSE;

	case WM_CLOSE:
		if(g_szDumpTo) {
			hfree(g_szDumpTo);
		}
		if(g_szDumpFrom) {
			hfree(g_szDumpFrom);
		}
		EndDialog(hwndDlg,0);
		return TRUE;
	}
	return FALSE;
}

void SetEditText (LPWSTR text, int id) {
	SendDlgItemMessageW(g_hMain, id, WM_SETTEXT, 0, (LPARAM)text);
}

void NotImplemented () {
	MessageBoxW(g_hMain, L"Function is not implemented yet.", L"Pick", MB_ICONINFORMATION | MB_OK);
}

LPWSTR MakeFileNameBufferW () {
	return (LPWSTR)halloc(2*MAX_PATH_W);
}

LPVOID halloc (size_t dwBytes) {
	return HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dwBytes);
}

void hfree (LPVOID lpMem) {
	HeapFree(GetProcessHeap(), 0, lpMem);
}

LONG WINAPI seh (struct _EXCEPTION_POINTERS *ei) {
	MessageBoxW(0, L"Error detected. \nApplication will exit.", L"SEH", MB_ICONERROR | MB_OK);
	return EXCEPTION_CONTINUE_SEARCH;
}
//
LPWSTR GetTargetPathDirectory () {
	HRESULT hr = CoInitialize(NULL);
	LPWSTR fileName = MakeFileNameBufferW();
	BROWSEINFOW bInfo;
	LPITEMIDLIST lpItem;

	tiny_mem_set(&bInfo, 0, sizeof(BROWSEINFOW));
	if (SUCCEEDED(hr)) {
		bInfo.hwndOwner = g_hMain;
		bInfo.pidlRoot = NULL;
		bInfo.pszDisplayName = fileName;
		bInfo.lpszTitle = L"Open folder to be dumped";

		bInfo.ulFlags = BIF_NONEWFOLDERBUTTON
			| BIF_USENEWUI
			| BIF_SHAREABLE
			| BIF_VALIDATE
			| BIF_RETURNONLYFSDIRS;

		lpItem = SHBrowseForFolderW(&bInfo);

		if (lpItem != NULL) {
			SHGetPathFromIDListW(lpItem, fileName);
			CoTaskMemFree(lpItem);
		} else {
			//MessageBoxW(0, L"GetTargetPathDirectory(): SHBrowseForFolderW() failed\n", L"Error", MB_ICONERROR|MB_OK);
			hfree(fileName);
			fileName = 0;
		}
		CoUninitialize();
	} else {
		MessageBoxW(0, L"GetTargetPathDirectory(): CoInitialize() failed\n", L"Error", MB_ICONERROR|MB_OK);
		hfree(fileName);
		fileName = 0;
	}
	return fileName;
}

LPWSTR GetDumpSaveFileName () {
	OPENFILENAMEW ofn;
	LPWSTR fileName;
	int iret;

	tiny_mem_set(&ofn, 0, sizeof(OPENFILENAMEW));
	fileName = MakeFileNameBufferW();
	ofn.lStructSize = sizeof(OPENFILENAMEW);
	ofn.hwndOwner = g_hMain;
	ofn.lpstrTitle = L"Save dump as";
	ofn.lpstrFilter = L"File list dump (*.fld)\0*.fld\0\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFile = fileName;
	ofn.nMaxFile = MAX_PATH_W;
	ofn.Flags = OFN_LONGNAMES|OFN_NOREADONLYRETURN|OFN_OVERWRITEPROMPT
		|OFN_PATHMUSTEXIST|OFN_DONTADDTORECENT|OFN_FORCESHOWHIDDEN;
	ofn.lpstrDefExt = L"fld";

	iret = GetSaveFileNameW(&ofn);
	if(!iret) {
		hfree(fileName);
		fileName = (LPWSTR)0;
	}
	return fileName;
}

//
void StartDumpFiles () {
	g_stop = FALSE;
	g_hThr = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)DumpFiles, 0, 0, &g_dwTid);
}

void StartDumpFiles__ () {
	EnableWindow(GetDlgItem(g_hMain, IDB_DUMP), FALSE);
	EnableWindow(GetDlgItem(g_hMain, IDB_DUMP_STOP), TRUE);
}

void StopDumpFiles () {
	//PostThreadMessage(g_dwTid, WM_QUIT, 0, 0);
	g_stop = TRUE;
}

void StopDumpFiles__ () {
	EnableWindow(GetDlgItem(g_hMain, IDB_DUMP), TRUE);
	EnableWindow(GetDlgItem(g_hMain, IDB_DUMP_STOP), FALSE);
	MessageBoxW(g_hMain, g_stop? L"Process interrupted" : L"Dump completed", L"Pick", MB_ICONINFORMATION|MB_OK);
}

void DumpFiles (LPVOID lpParam) {
	LPWSTR path, dfn, dfi;
	HANDLE tmp;
	SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)seh);
	StartDumpFiles__();
	dfn = MakeFileNameBufferW();
	lstrcpyW(dfn, g_szDumpTo);
	lstrcatW(dfn, L".name");
	dfi = MakeFileNameBufferW();
	lstrcpyW(dfi, g_szDumpTo);
	lstrcatW(dfi, L".info");
	g_dumpFile = CreateFileW(g_szDumpTo, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	g_dumpFileName = CreateFileW(dfn, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	g_dumpFileInfo = CreateFileW(dfi, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	if(g_dumpFile != NULL && g_dumpFileName != NULL && g_dumpFileInfo != NULL) {
		path = MakeFileNameBufferW();
		lstrcpyW(path, L"\\\\?\\");
		if(g_szDumpFrom[0] == L'\\' && g_szDumpFrom[1] == L'\\') {
			lstrcatW(path, L"UNC");
			lstrcatW(path, &g_szDumpFrom[1]);
		} else {
			lstrcatW(path, g_szDumpFrom);
		}
		if(path[lstrlenW(path)-1] != L'\\') {
			lstrcatW(path, L"\\");
		}
		lstrcatW(path, L"*");
		RecursiveSearchFiles(path);
		CloseHandle(g_dumpFile);
		CloseHandle(g_dumpFileName);
		CloseHandle(g_dumpFileInfo);
		if(g_stop) {
			lstrcpyW(dfi, g_szDumpTo);
			lstrcatW(dfi, L".interrupted");
			tmp = CreateFileW(dfi, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
			CloseHandle(tmp);
		}
		SetEditText(g_stop? L"interrupted" : L"completed", IDS_DUMP_STATUS);
	} else {
		__WTF(L"DumpFiles(): CreateFileW()");
		SetEditText(L"failed", IDS_DUMP_STATUS);
	}
	hfree(dfi);
	hfree(dfn);
	StopDumpFiles__();
	ExitThread(0);
}

void RecursiveSearchFiles (LPWSTR path) {
	WIN32_FIND_DATAW fd;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	DWORD w;
	int pl;
	LPWSTR np;

	hFind = FindFirstFileW(path, &fd);
	if (hFind != INVALID_HANDLE_VALUE) {
		np = MakeFileNameBufferW();
		lstrcpyW(np, path);
		pl = lstrlenW(path)-1;
		do {
			if(lstrcmpW(fd.cFileName, L".") == 0 || lstrcmpW(fd.cFileName, L"..") == 0) {
			} else {
				WriteFile(g_dumpFileInfo, &fd, sizeof(WIN32_FIND_DATAW)-2*(MAX_PATH+14), &w, 0);
				np[pl] = L'\0';
				lstrcatW(np, fd.cFileName);
				WriteFile(g_dumpFileName, (LPVOID)np, (lstrlenW(np)+1)*2, &w, 0);
				if(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
					lstrcatW(np, L"\\*");
					RecursiveSearchFiles(np);
				}
			}
		} while (FindNextFileW(hFind, &fd) != 0 && !g_stop);

		if(!g_stop) {
			w = GetLastError();
			if (w != ERROR_NO_MORE_FILES) {
				__WTF(L"RecursiveSearchFiles(): FindNextFileW()");
			}
		}
		hfree(np);
		FindClose(hFind);
	}
}

void __WTF (LPWSTR addText) {
	LPVOID lpMsgBuf;
	DWORD dw = GetLastError();

	FormatMessageW(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		dw,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPWSTR) &lpMsgBuf,
		0, NULL );
	MessageBoxW(NULL, (LPWSTR)lpMsgBuf, (LPWSTR)addText, MB_OK);

	LocalFree(lpMsgBuf);
}
