#pragma comment(linker, "/ENTRY:win32tiny_entry")

#include <windows.h>
#include <Shlobj.h>
#include "res.h"

void * __cdecl tiny_mem_set(void *pTarget, char value, size_t cbTarget) {
	_asm {
		push ecx
			push edi

			mov al, value
			mov ecx, cbTarget
			mov edi, pTarget
			rep stosb

			pop edi
			pop ecx
	}
	return pTarget;
}

#define MAX_PATH_W 32767

// global variables
HWND g_hMain;
HINSTANCE g_hInstance;
LPWSTR g_szDumpFrom;

// function prototypes
static BOOL CALLBACK DialogFunc (HWND, UINT, WPARAM, LPARAM);
void NotImplemented ();
LPWSTR GetDumpOpenFileName ();
LPWSTR GetTargetPathDirectory ();
LPWSTR MakeFileNameBufferW ();
LPVOID halloc (size_t);
void hfree (LPVOID);
void SetEditText (LPWSTR, int);
void StartDumpFiles ();
void StopDumpFiles ();
void StartDumpFiles__ ();
void StopDumpFiles__ ();
void DumpFiles (LPVOID);
void RecursiveSearchFiles (LPWSTR);
LONG WINAPI seh (struct _EXCEPTION_POINTERS *);
void __WTF(LPWSTR);

void __stdcall win32tiny_entry () {
	UINT uRet;

	SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)seh);
	uRet =  DialogBoxW(GetModuleHandleW(0), MAKEINTRESOURCEW(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);

	ExitProcess(uRet);
}

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam) {
	LPWSTR ts;
	switch (msg) {
	case WM_INITDIALOG:
		g_hMain = hwndDlg;
		g_szDumpFrom = MakeFileNameBufferW();
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDB_SIZE:
			SetEditText(L"in progress", IDS_DUMP_STATUS);
			GetWindowTextW(GetDlgItem(g_hMain, IDE_DUMP_FROM), g_szDumpFrom, MAX_PATH_W);
			DumpFiles(0);
			SetEditText(L"completed", IDS_DUMP_STATUS);
			return TRUE;
		case IDB_DUMP_FROM_BROWSE:
			ts = GetDumpOpenFileName();
			if(ts) {
				SetEditText(ts, IDE_DUMP_FROM);
				hfree(ts);
			}
			return TRUE;
		}
		return FALSE;

	case WM_CLOSE:
		if(g_szDumpFrom) {
			hfree(g_szDumpFrom);
		}
		EndDialog(hwndDlg,0);
		return TRUE;
	}
	return FALSE;
}

void SetEditText (LPWSTR text, int id) {
	SendDlgItemMessageW(g_hMain, id, WM_SETTEXT, 0, (LPARAM)text);
}

void NotImplemented () {
	MessageBoxW(g_hMain, L"Function is not implemented yet.", L"Pick", MB_ICONINFORMATION | MB_OK);
}

LPWSTR MakeFileNameBufferW () {
	return (LPWSTR)halloc(2*MAX_PATH_W);
}

LPVOID halloc (size_t dwBytes) {
	return HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dwBytes);
}

void hfree (LPVOID lpMem) {
	HeapFree(GetProcessHeap(), 0, lpMem);
}

LONG WINAPI seh (struct _EXCEPTION_POINTERS *ei) {
	MessageBoxW(0, L"Error detected. \nApplication will exit.", L"SEH", MB_ICONERROR | MB_OK);
	return EXCEPTION_CONTINUE_SEARCH;
}
//
LPWSTR GetDumpOpenFileName () {
	OPENFILENAMEW ofn;
	LPWSTR fileName;
	int iret;

	tiny_mem_set(&ofn, 0, sizeof(OPENFILENAMEW));
	fileName = MakeFileNameBufferW();
	ofn.lStructSize = sizeof(OPENFILENAMEW);
	ofn.hwndOwner = g_hMain;
	ofn.lpstrTitle = L"Open dump";
	ofn.lpstrFilter = L"File list dump (*.fld)\0*.fld\0\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFile = fileName;
	ofn.nMaxFile = MAX_PATH_W;
	ofn.Flags = OFN_LONGNAMES|OFN_PATHMUSTEXIST|OFN_DONTADDTORECENT|OFN_FORCESHOWHIDDEN|OFN_FILEMUSTEXIST;
	ofn.lpstrDefExt = L"fld";

	iret = GetOpenFileNameW(&ofn);
	if(!iret) {
		hfree(fileName);
		fileName = (LPWSTR)0;
	}
	return fileName;
}
//
void DumpFiles (LPVOID lpParam) {
	LPWSTR dfi, buf;
	HANDLE tmp;
	DWORD r, sh, sl, c, i, _m, f;
	WIN32_FIND_DATAW fd;
	dfi = MakeFileNameBufferW();
	lstrcpyW(dfi, g_szDumpFrom);
	lstrcatW(dfi, L".info");
	tmp = CreateFileW(dfi, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if(tmp != NULL) {
		sh = 0;
		sl = 0;
		i = 0;
		f = 0;
		do {
			ReadFile(tmp, &fd, sizeof(WIN32_FIND_DATAW)-2*(MAX_PATH+14), &r, 0);
			if(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
				f ++;
			} else {
				sh += fd.nFileSizeHigh;
				c = (((sl&fd.nFileSizeLow)&1) + (sl>>1) + (fd.nFileSizeLow>>1))&0x80000000;
				if(c) {
					sh ++;
				}
				sl += fd.nFileSizeLow;
				i ++;
			}
		} while (r);
		CloseHandle(tmp);
		buf = (LPWSTR)halloc(2*128);
		_m = (sl >> 20) + (sh << 12);
		wsprintfW(buf, L"[%08X]:[%08X], %lu files, %lu folders, ~%lu MB", sh, sl, i, f, _m);
		SetEditText(buf, IDE_SIZE);
		hfree(buf);
	} else {
		__WTF(L"DumpFiles(): CreateFileW()");
		SetEditText(L"failed", IDS_DUMP_STATUS);
	}
	hfree(dfi);
}

void __WTF (LPWSTR addText) {
	LPVOID lpMsgBuf;
	DWORD dw = GetLastError();

	FormatMessageW(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		dw,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPWSTR) &lpMsgBuf,
		0, NULL );
	MessageBoxW(NULL, (LPWSTR)lpMsgBuf, (LPWSTR)addText, MB_OK);

	LocalFree(lpMsgBuf);
}
